﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bombazo.Model
{
    public interface ITimer
    {
        bool Enabled { get; set; }
        double Interval { get; set; }
        void Start();
        void Stop();
    }
}
