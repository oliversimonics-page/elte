﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Bombazo.Persistence;

namespace Bombazo.Model
{
    public class BombazoModel
    {

        #region Fields
        private BombazoFileDataAccess _dataAccess; // adatelérés
        private BombazoTable _table; // játéktábla
        public int gameTime;
        public BombazoTimerAggregation timer;
        public bool IsGameOver;
        #endregion

        public void MovePlayer(int dx, int dy)
        {
            try
            {
                if(_table.MovePlayer(dx, dy))
                {
                    OnFieldChanged(_table._playerX - dx, _table._playerY - dy);
                    OnFieldChanged(_table._playerX, _table._playerY);
                }
            }
            catch(Exception)
            {
                OnGameOver();
            }
        }
        public async void PlaceBomb()
        {
            int bombX = _table._playerX;
            int bombY = _table._playerY + 1;
            if (_table.PlaceBomb())
            {
                OnFieldChanged(bombX, bombY);
                await Task.Delay(3000); // 3 másodperc
               
                try
                {
                    _table.Explode(bombX, bombY);
                }
                catch (Exception)
                {
                    OnGameOver();
                }

                for (int i = bombX - 3; i <= bombX + 3; i++)
                    for (int j = bombY - 3; j <= bombY + 3; j++)
                        if (i >= 0 && j >= 0 && i < _table.Size && j < _table.Size)
                            OnFieldChanged(i, j);
            }
        }

        #region Properties
        public int TableSize => _table.Size;
        public int KilledEnemies => _table._enemiesKilled;
        public FieldType this[int x, int y] => _table[x, y];
        #endregion

        #region Events
        public event EventHandler<BombazoFieldEventArgs>? FieldChanged;
        public event EventHandler<BombazoEventArgs>? GameAdvanced;
        public event EventHandler<BombazoEventArgs>? GameOver;
        #endregion

        #region Constructor
        public BombazoModel(int tableSize)
        {   
            _dataAccess = new BombazoFileDataAccess();
            timer = new BombazoTimerAggregation();
            timer.Interval = 1000;
            timer.Elapsed += new EventHandler(Timer_Elapsed);
            _table = new BombazoTable(tableSize);
        }
        #endregion

        #region Public table accessors
        public FieldType GetValue(int x, int y) => _table[x, y];
        public bool IsEmpty(int x, int y) => _table.IsEmpty(x, y);
        public bool IsWall(int x, int y) => _table.IsWall(x, y);
        public bool IsEnemy(int x, int y) => _table.IsEnemy(x, y);
        public bool IsPlayer(int x, int y) => _table.IsPlayer(x, y);
        public bool IsBomb(int x, int y) => _table.IsBomb(x, y);
        #endregion

        #region Game options
        public void NewGame(int size)
        {
            PauseGame();
            IsGameOver = false;
            gameTime = 0;
            timer.Start();
        }
        public void PauseGame()
        {
            timer.Stop();
        }

        public void ResumeGame()
        {
            if (!IsGameOver)
                timer.Start();
        }

        public async Task LoadGameAsync(String path)
        {
            PauseGame();
            if (_dataAccess == null)
                throw new InvalidOperationException("No data access is provided.");

            _table = await _dataAccess.LoadAsync(path);
            gameTime = 0;
            timer.Start();
        }

        public async Task SaveGameAsync(String path)
        {
            if (_dataAccess == null)
                throw new InvalidOperationException("No data access is provided.");

            await _dataAccess.SaveAsync(path, _table);
        }

        #endregion

        #region Private game methods

        private void Timer_Elapsed(Object? sender, EventArgs e)
        {
            gameTime++;
            try
            {
                _table.MoveEnemies();
            }
            catch(Exception)
            {
                OnGameOver();
            }
            OnGameAdvanced();
            for (int i = 0; i < _table.Size; i++)
                for (int j = 0; j < _table.Size; j++)
                    OnFieldChanged(i, j);
            if (_table.IsWin)
            {
                OnGameOver();
            }
        }
        #endregion

        #region Private event methods

        private void OnFieldChanged(int x, int y)
        {
            FieldChanged?.Invoke(this, new BombazoFieldEventArgs(x, y));
        }
        private void OnGameAdvanced()
        {
            GameAdvanced?.Invoke(this, new BombazoEventArgs(_table.IsWin, gameTime, KilledEnemies));
        }

        private void OnGameOver()
        {
            timer.Stop();
            IsGameOver = true;
            GameOver?.Invoke(this, new BombazoEventArgs(_table.IsWin, gameTime, KilledEnemies));
        }
        
        #endregion

    }
}
