﻿using System;

namespace Bombazo.Model
{
    public class BombazoFieldEventArgs : EventArgs
    {
        private int _changedFieldX;
        private int _changedFieldY;
        public int X { get { return _changedFieldX; } }
        public int Y { get { return _changedFieldY; } }
        public BombazoFieldEventArgs(int x, int y) 
        {
            _changedFieldX = x;
            _changedFieldY = y;
        }
    }
}
