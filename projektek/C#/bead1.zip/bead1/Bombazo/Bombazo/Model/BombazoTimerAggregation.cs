﻿using System;
using System.Collections.Generic;
using System.Timers;


namespace Bombazo.Model
{
    public class BombazoTimerAggregation : ITimer, IDisposable
    {
        #region mezok
        private System.Timers.Timer _timer;
        public bool Enabled
        {
            get => _timer.Enabled;
            set => _timer.Enabled = value;
        }
        public double Interval
        {
            get => _timer.Interval;
            set => _timer.Interval = value;
        }
        public event EventHandler? Elapsed;
        #endregion
        public BombazoTimerAggregation()
        {
            _timer = new System.Timers.Timer();
            _timer.Elapsed += (sender, e) =>
            {
                Elapsed?.Invoke(sender, e);
            };
        }
        public void Start()
        {
            _timer.Start();
        }
        public void Stop()
        {
            _timer.Stop();
        }
        public void Dispose()
        {
            // Mivel IDisposable adattagot aggregáltunk, a <see cref="BombazoTimerAggregation"/> típusnak is disposable-nek kell lennie.
            _timer.Dispose();
        }
    }
}