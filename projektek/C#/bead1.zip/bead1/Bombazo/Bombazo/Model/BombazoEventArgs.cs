﻿using System;

namespace Bombazo.Model
{
    public class BombazoEventArgs : EventArgs
    {
        private int _gameTime;
        private bool _isWon;
        private int _enemiesKilled;

        public int GameTime { get { return _gameTime; } }
        public int EnemiesKilled => _enemiesKilled;
        public bool IsWon { get { return _isWon; } }
        public BombazoEventArgs(bool isWon, int gameTime, int enemiesKilled) 
        { 
            _isWon = isWon;
            _gameTime = gameTime;
            _enemiesKilled = enemiesKilled;
        }
    }
}
