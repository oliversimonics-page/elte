﻿using System;

namespace Bombazo.Persistence
{
    public class BombazoDataException : Exception
    {
        public BombazoDataException() { }
    }
}
