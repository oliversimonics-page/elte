﻿using System;

namespace Bombazo.Persistence
{
    
    public enum FieldType {Empty, Player, Enemy, Wall, Bomb}

    public class BombazoTable
    {
        #region Fields
        private FieldType[,] _fields;
        public int _playerX;
        public int _playerY;
        public int _enemiesKilled;
        private Random _random = new Random();
        private Dictionary<(int x, int y), (int dx, int dy)> _enemyDirections = [];

        #endregion

        #region Properties
        
        public bool IsWin
        {
            get
            {
                foreach (FieldType value in _fields)
                    if (value == FieldType.Enemy)
                        return false;
                return true;
            }
        }

        public int Size
        {
            get { return _fields.GetLength(0); }
        }

        public FieldType this[int x, int y]
        {
            get { return GetValue(x, y); }
            set
            {
                if (x < 0 || x >= Size || y < 0 || y >= Size)
                    throw new ArgumentOutOfRangeException();
                _fields[x, y] = value;
            }
        }

        #endregion

        #region Constructors
        public BombazoTable(int tableSize)
        {
            if (tableSize != 12 && tableSize != 16 && tableSize != 20)
                throw new ArgumentOutOfRangeException(nameof(tableSize), "The table size is less than 0.");

            _fields = new FieldType[tableSize, tableSize];
        }

        #endregion

        #region Public methods
        public bool MovePlayer(int dx, int dy)
        {
            int newX = _playerX + dx;
            int newY = _playerY + dy;

            // határok ellenőrzése
            if (newX < 0 || newY < 0 || newX >= Size || newY >= Size)
                return false;

            // falba nem mehet
            if (_fields[newX, newY] == FieldType.Wall)
                return false;

            if (_fields[newX, newY] == FieldType.Bomb)
                return false;

            // ha ellenségre lép -> game over
            if (_fields[newX, newY] == FieldType.Enemy)
                throw new Exception("Game Over!");

            // mozgás
            _fields[_playerX, _playerY] = FieldType.Empty;
            _playerX = newX;
            _playerY = newY;
            _fields[_playerX, _playerY] = FieldType.Player;

            return true;
        }
        public bool PlaceBomb()
        {
            int X1 = _playerX;
            int Y1 = _playerY + 1;
            if (X1 < 0 || Y1 < 0 || X1 >= Size || Y1 >= Size)
                return false;
            if (_fields[X1, Y1] == FieldType.Wall || _fields[X1, Y1] == FieldType.Enemy || _fields[X1, Y1] == FieldType.Wall)
                return false;
            _fields[X1, Y1] = FieldType.Bomb;
            return true;
        }
        public void Explode(int x, int y, int radius = 3)
        {
            for (int i = x - radius; i <= x + radius; i++)
                for (int j = y - radius; j <= y + radius; j++)
                {
                    if (i < 0 || j < 0 || i >= Size || j >= Size)
                        continue;

                    if (_fields[i, j] == FieldType.Player)
                        throw new Exception("Game Over!");
                    if (_fields[i, j] == FieldType.Enemy)
                    {
                        _fields[i, j] = FieldType.Empty; // ellenség meghal

                        _enemiesKilled++;
                    }

                    if (_fields[i, j] == FieldType.Bomb)
                        _fields[i, j] = FieldType.Empty; // bomba eltűnik
                }
        }

        public void MoveEnemies()
        {
            List<(int x, int y)> enemies = new();

            for (int i = 0; i < Size; i++)
                for (int j = 0; j < Size; j++)
                    if (_fields[i, j] == FieldType.Enemy)
                        enemies.Add((i, j));

            foreach ((int x, int y) in enemies)
            {
                if (!_enemyDirections.ContainsKey((x, y)))
                    _enemyDirections[(x, y)] = GetRandomDirection(0, 0);

                (int dx, int dy) = _enemyDirections[(x, y)];

                // ha falba ütközne vagy kimegy a pályáról, addig keres új irányt
                int tries = 0; // ha beragadna ne akadjon ki
                while ((x + dx < 0 || y + dy < 0 || x + dx >= Size || y + dy >= Size || //ha kimenne a pályáról
                       _fields[x + dx, y + dy] == FieldType.Wall || _fields[x + dx, y + dy] == FieldType.Enemy // ha nekimenne valami másnak
                       || _fields[x + dx, y + dy] == FieldType.Bomb) && tries < 10)
                {
                    _enemyDirections[(x, y)] = GetRandomDirection(dx, dy);
                    (dx, dy) = _enemyDirections[(x, y)];
                    tries++;
                }

                int newX = x + dx;
                int newY = y + dy;

                // ha játékost elér -- game over
                if (_fields[newX, newY] == FieldType.Player)
                    throw new Exception("Game Over!");
                //frissítés
                _fields[x, y] = FieldType.Empty;
                _fields[newX, newY] = FieldType.Enemy;
                //
                _enemyDirections.Remove((x, y));
                _enemyDirections[(newX, newY)] = (dx, dy);
            }

        }
        #endregion

        #region checks
        public bool IsEmpty(int x, int y)
        {
            if (x < 0 || x >= _fields.GetLength(0))
                throw new ArgumentOutOfRangeException(nameof(x), "The X coordinate is out of range.");
            if (y < 0 || y >= _fields.GetLength(1))
                throw new ArgumentOutOfRangeException(nameof(y), "The Y coordinate is out of range.");

            return _fields[x, y] == FieldType.Empty;
        }

        public bool IsEnemy(int x, int y)
        {
            if (x < 0 || x >= _fields.GetLength(0))
                throw new ArgumentOutOfRangeException(nameof(x), "The X coordinate is out of range.");
            if (y < 0 || y >= _fields.GetLength(1))
                throw new ArgumentOutOfRangeException(nameof(y), "The Y coordinate is out of range.");

            return _fields[x, y] == FieldType.Enemy;
        }

        public bool IsWall(int x, int y)
        {
            if (x < 0 || x >= _fields.GetLength(0))
                throw new ArgumentOutOfRangeException(nameof(x), "The X coordinate is out of range.");
            if (y < 0 || y >= _fields.GetLength(1))
                throw new ArgumentOutOfRangeException(nameof(y), "The Y coordinate is out of range.");

            return _fields[x, y] == FieldType.Wall;
        }
        public bool IsPlayer(int x, int y)
        {
            if (x < 0 || x >= _fields.GetLength(0))
                throw new ArgumentOutOfRangeException(nameof(x), "The X coordinate is out of range.");
            if (y < 0 || y >= _fields.GetLength(1))
                throw new ArgumentOutOfRangeException(nameof(y), "The Y coordinate is out of range.");

            return _fields[x, y] == FieldType.Player;
        }
        public bool IsBomb(int x, int y)
        {
            if (x < 0 || x >= _fields.GetLength(0))
                throw new ArgumentOutOfRangeException(nameof(x), "The X coordinate is out of range.");
            if (y < 0 || y >= _fields.GetLength(1))
                throw new ArgumentOutOfRangeException(nameof(y), "The Y coordinate is out of range.");

            return _fields[x, y] == FieldType.Bomb;
        }
        private FieldType GetValue(int x, int y)
        {
            if (x < 0 || x >= _fields.GetLength(0))
                throw new ArgumentOutOfRangeException(nameof(x), "The X coordinate is out of range.");
            if (y < 0 || y >= _fields.GetLength(1))
                throw new ArgumentOutOfRangeException(nameof(y), "The Y coordinate is out of range.");
            return _fields[x, y];
        }
        #endregion
        
        private (int dx, int dy) GetRandomDirection(int curx, int cury)
        {
            (int, int)[] directions =
            [
                (1, 0),  // jobbra
                (-1, 0), // balra
                (0, 1),  // le
                (0, -1)  // fel
            ];
            int index = _random.Next(4);
            
            if ((directions[index]) == (curx, cury))
            {
                index = (index + 1) % 4;
            }// ha ugyanaz az irány lenne akkor a következőre lépteti*/
            return (directions[index]);
        }
    }
}
