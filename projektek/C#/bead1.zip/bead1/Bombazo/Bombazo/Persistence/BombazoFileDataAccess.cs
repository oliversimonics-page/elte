﻿using System;
using System.IO;
using System.Threading.Tasks;
using Bombazo;

namespace Bombazo.Persistence
{
    public class BombazoFileDataAccess
    {
        public async Task<BombazoTable> LoadAsync(String path)
        {
            try
            {
                using StreamReader reader = new(path); // fájl megnyitása
                string line = await reader.ReadLineAsync() ?? String.Empty;
                int tableSize = int.Parse(line); // beolvassuk a tábla méretét
                BombazoTable table = new(tableSize); // létrehozzuk a táblát

                for (int i = 0; i < tableSize; i++)
                {
                    line = await reader.ReadLineAsync() ?? String.Empty;
                    string[] numbers = line.Split(' ');

                    for (int j = 0; j < tableSize; j++)
                    {
                        FieldType field = numbers[j] switch
                        {
                            "E" => FieldType.Empty,
                            "O" => FieldType.Enemy,
                            "W" => FieldType.Wall,
                            "P" => FieldType.Player,
                            "B" => FieldType.Bomb,
                            _ => throw new BombazoDataException()
                        };
                        table[i, j] = field;
                    }
                }
                return table;
            }
            catch 
            {
                throw new Exception();
            }
        }

        public async Task SaveAsync(string path, BombazoTable table)
        {
            try
            {
                using StreamWriter writer = new(path); // fájl megnyitása
                await writer.WriteLineAsync(table.Size.ToString()); // kiírjuk a méretet
                for (int i = 0; i < table.Size; i++)
                {
                    for (int j = 0; j < table.Size; j++)
                    {
                        string l = table[i, j] switch
                        {
                            FieldType.Empty => "E",
                            FieldType.Enemy => "O",
                            FieldType.Wall => "W",
                            FieldType.Player => "P",
                            FieldType.Bomb => "B",
                            _ => throw new BombazoDataException()
                        };
                        await writer.WriteAsync(l + " "); // kiírjuk az értékeket
                    }
                    await writer.WriteLineAsync();
                }
            }
            catch 
            {
                throw new Exception();
            }
        }
    }
}
