using Bombazo.Model;
using Bombazo.Persistence;
using System.IO;
using System.Windows.Forms;
namespace bombazo
{
    public partial class Form1 : Form
    {
        private BombazoModel _model; // j�t�kmodell
        private Button[,] _buttonGrid = null!; //p�lya
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;
            BombazoFileDataAccess _dataAccess = new BombazoFileDataAccess();

            _model = new BombazoModel(16);
            // feliratkoz�sok
            _model.FieldChanged += new EventHandler<BombazoFieldEventArgs>(Game_FieldChanged);
            _model.GameAdvanced += new EventHandler<BombazoEventArgs>(UpdateStatusBar);
            _model.GameOver += new EventHandler<BombazoEventArgs>(Game_GameOver);
        }
        private async void Form1_Load(object sender, EventArgs e)
        {
            await _model.LoadGameAsync("Input/16.txt");
            GenerateTable();
            SetupTable();
            SetupMenus();
        }
        #region eventhandling
        private void Form1_KeyDown(object? sender, KeyEventArgs e)
        {
            if (_model.IsGameOver)
                return;
            switch (e.KeyCode)
            {
                case Keys.W:
                    _model.MovePlayer(-1, 0); // felfel�
                    break;
                case Keys.S:
                    _model.MovePlayer(1, 0); // lefel�
                    break;
                case Keys.A:
                    _model.MovePlayer(0, -1); // balra
                    break;
                case Keys.D:
                    _model.MovePlayer(0, 1); // jobbra
                    break;
                case Keys.E:
                    _model.PlaceBomb(); // jobbra
                    break;
            }
        }
        private void UpdateStatusBar(object? sender, BombazoEventArgs e)
        {
            statusLabel.Text = $"Enemies killed: {e.EnemiesKilled} | Elapsed time: " + TimeSpan.FromSeconds(e.GameTime).ToString(@"mm\:ss");
        }
        private void Game_GameOver(Object? sender, BombazoEventArgs e)
        {
            foreach (Button button in _buttonGrid) // kikapcsoljuk a gombokat
                button.Enabled = false;

            _menuFileSaveGame.Enabled = false;

            if (e.IsWon) // gy�zelemt�l f�gg� �zenet megjelen�t�se
            {
                MessageBox.Show("Gratul�lok, gy�zt�l!" + Environment.NewLine +
                                "�sszesen " + e.EnemiesKilled + " ellenfelet �lt�l meg �s " +
                                TimeSpan.FromSeconds(e.GameTime).ToString("g") + " ideig j�tszott�l.",
                    "Bomb�z� j�t�k",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Asterisk);
            }
            else
            {
                MessageBox.Show("Sajn�lom, vesztett�l!",
                    "Bomb�z� j�t�k",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Asterisk);
            }
        }
        private void Game_FieldChanged(object? sender, BombazoFieldEventArgs e)
        {
            if (_model.IsEmpty(e.X, e.Y))
                _buttonGrid[e.X, e.Y].BackColor = Color.White;
            if (_model.IsWall(e.X, e.Y))
                _buttonGrid[e.X, e.Y].BackColor = Color.Black;
            if (_model.IsPlayer(e.X, e.Y))
                _buttonGrid[e.X, e.Y].BackColor = Color.Green;
            if (_model.IsBomb(e.X, e.Y))
                _buttonGrid[e.X, e.Y].BackColor = Color.Red;
            if (_model.IsEnemy(e.X, e.Y))
                _buttonGrid[e.X, e.Y].BackColor = Color.Blue;
        }
        #endregion

        #region setups
        private void GenerateTable()
        {
            if (_buttonGrid != null) //kit�r�lj�k a gombokat ha �j p�ly�t szeretn�nk
            {
                foreach (Button b in _buttonGrid)
                    b.Dispose();
            }
            _buttonGrid = new Button[_model.TableSize, _model.TableSize];
            for (int i = 0; i < _model.TableSize; i++)
                for (int j = 0; j < _model.TableSize; j++)
                {
                    _buttonGrid[i, j] = new Button();
                    _buttonGrid[i, j].Location = new Point(5 + 40 * j, 35 + 40 * i); // elhelyezked�s
                    _buttonGrid[i, j].Size = new Size(40, 40); // m�ret
                    _buttonGrid[i, j].Enabled = false; // kikapcsolt �llapot
                    _buttonGrid[i, j].TabIndex = 100 + i * _model.TableSize + j; // a gomb sz�m�t a TabIndex-ben t�roljuk
                    _buttonGrid[i, j].FlatStyle = FlatStyle.Flat; // lap�tott st�pus

                    Controls.Add(_buttonGrid[i, j]);
                }
            this.ClientSize = new Size(40 * _model.TableSize + 20,40 * _model.TableSize + statusStrip1.Height + 80);
        }
        private void SetupTable()
        {
            for (int i = 0; i < _buttonGrid.GetLength(0); i++)
            {
                for (int j = 0; j < _buttonGrid.GetLength(1); j++)
                {
                    _buttonGrid[i, j].Text = String.Empty;
                    _buttonGrid[i, j].Enabled = false;
                    if (_model.IsEmpty(i, j))
                        _buttonGrid[i, j].BackColor = Color.White;
                    if (_model.IsWall(i, j))
                        _buttonGrid[i, j].BackColor = Color.Black;
                    if (_model.IsPlayer(i, j))
                        _buttonGrid[i, j].BackColor = Color.Green;
                    if (_model.IsBomb(i, j))
                        _buttonGrid[i, j].BackColor = Color.Red;
                    if (_model.IsEnemy(i, j))
                        _buttonGrid[i, j].BackColor = Color.Blue;
                }
            }
        }
        private void SetupMenus()
        {
            kicsiToolStripMenuItem.Checked = (_model.TableSize == 12);
            k�zepesToolStripMenuItem.Checked = (_model.TableSize == 16);
            nagyToolStripMenuItem.Checked = (_model.TableSize == 20);
        }
        #endregion

        #region Clicks
        private async void KicsiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _model.NewGame(12);
            await _model.LoadGameAsync("Input/12.txt");
            GenerateTable();
            SetupTable();
            SetupMenus();
        }
        private async void K�zepesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _model.NewGame(16);
            await _model.LoadGameAsync("Input/16.txt");
            GenerateTable();
            SetupTable();
            SetupMenus();
        }
        private async void NagyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _model.NewGame(20);
            await _model.LoadGameAsync("Input/20.txt");
            GenerateTable();
            SetupTable();
            SetupMenus();
        }
        private async void NewGameMenuItem_Click(object sender, EventArgs e)
        {
            _model.NewGame(_model.TableSize);
            await _model.LoadGameAsync($"Input/{_model.TableSize}.txt");
            GenerateTable();
            SetupTable();
            SetupMenus();
        }
        private async void MenuFileLoad_Click(object sender, EventArgs e)
        {
            _model.PauseGame();
            if (openFileDialog.ShowDialog() == DialogResult.OK) // ha kiv�lasztottunk egy f�jlt
            {
                try
                {
                    // j�t�k bet�lt�se
                    await _model.LoadGameAsync(openFileDialog.FileName);
                    _menuFileSaveGame.Enabled = true;
                }
                catch (BombazoDataException)
                {
                    MessageBox.Show(
                        "J�t�k bet�lt�se sikertelen!" + Environment.NewLine +
                        "Hib�s az el�r�si �t, vagy a f�jlform�tum.", "Hiba!", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    _model.NewGame(_model.TableSize);
                    _menuFileSaveGame.Enabled = true;
                }
                GenerateTable();
                SetupTable();
                SetupMenus();
            }
            else
            {
                _model.ResumeGame();
            }
        }
        private async void MenuFileSaveGame_Click(object sender, EventArgs e)
        {
            bool restartTimer = !_model.IsGameOver;
            _model.PauseGame();

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // j�t� ment�se
                    await _model.SaveGameAsync(saveFileDialog1.FileName);
                }
                catch (BombazoDataException)
                {
                    MessageBox.Show(
                        "J�t�k ment�se sikertelen!" + Environment.NewLine +
                        "Hib�s az el�r�si �t, vagy a k�nyvt�r nem �rhat�.", "Hiba!", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }

            if (restartTimer)
                _model.ResumeGame();
        }
        private void Kil�p�sToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool restartTimer = !_model.IsGameOver;
            _model.PauseGame();

            if (MessageBox.Show("Biztosan ki szeretne l�pni?", "Bombazo j�t�k", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
            else
            {
                if (restartTimer)
                    _model.ResumeGame();
            }
        }
        private void J�t�kMeg�ll�t�saToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _model.PauseGame();
            this.KeyDown -= Form1_KeyDown;
        }
        private void j�t�kFolytat�saToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.KeyDown -= Form1_KeyDown;
            this.KeyDown += Form1_KeyDown;
            _model.ResumeGame();
        }
        #endregion
    }
}
