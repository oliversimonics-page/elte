﻿using Bombazo.Model;
namespace bombazo
{
    public partial class Form1
    {

        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fieldsToolStripMenuItem = new ToolStripMenuItem();
            newGameMenuItem = new ToolStripMenuItem();
            _menuFileSaveGame = new ToolStripMenuItem();
            _menuFileLoad = new ToolStripMenuItem();
            kilépésToolStripMenuItem = new ToolStripMenuItem();
            méretToolStripMenuItem = new ToolStripMenuItem();
            kicsiToolStripMenuItem = new ToolStripMenuItem();
            közepesToolStripMenuItem = new ToolStripMenuItem();
            nagyToolStripMenuItem = new ToolStripMenuItem();
            játékMegállításaToolStripMenuItem = new ToolStripMenuItem();
            játékFolytatásaToolStripMenuItem = new ToolStripMenuItem();
            statusStrip1 = new StatusStrip();
            statusLabel = new ToolStripStatusLabel();
            openFileDialog = new OpenFileDialog();
            saveFileDialog1 = new SaveFileDialog();
            menuStrip1.SuspendLayout();
            statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fieldsToolStripMenuItem, méretToolStripMenuItem, játékMegállításaToolStripMenuItem, játékFolytatásaToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(682, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fieldsToolStripMenuItem
            // 
            fieldsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { newGameMenuItem, _menuFileSaveGame, _menuFileLoad, kilépésToolStripMenuItem });
            fieldsToolStripMenuItem.Name = "fieldsToolStripMenuItem";
            fieldsToolStripMenuItem.Size = new Size(46, 24);
            fieldsToolStripMenuItem.Text = "File";
            // 
            // newGameMenuItem
            // 
            newGameMenuItem.Name = "newGameMenuItem";
            newGameMenuItem.Size = new Size(146, 26);
            newGameMenuItem.Text = "Új játék";
            newGameMenuItem.Click += NewGameMenuItem_Click;
            // 
            // _menuFileSaveGame
            // 
            _menuFileSaveGame.Name = "_menuFileSaveGame";
            _menuFileSaveGame.Size = new Size(146, 26);
            _menuFileSaveGame.Text = "Mentés";
            _menuFileSaveGame.Click += MenuFileSaveGame_Click;
            // 
            // _menuFileLoad
            // 
            _menuFileLoad.Name = "_menuFileLoad";
            _menuFileLoad.Size = new Size(146, 26);
            _menuFileLoad.Text = "Betöltés";
            _menuFileLoad.Click += MenuFileLoad_Click;
            // 
            // kilépésToolStripMenuItem
            // 
            kilépésToolStripMenuItem.Name = "kilépésToolStripMenuItem";
            kilépésToolStripMenuItem.Size = new Size(146, 26);
            kilépésToolStripMenuItem.Text = "Kilépés";
            kilépésToolStripMenuItem.Click += KilépésToolStripMenuItem_Click;
            // 
            // méretToolStripMenuItem
            // 
            méretToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { kicsiToolStripMenuItem, közepesToolStripMenuItem, nagyToolStripMenuItem });
            méretToolStripMenuItem.Name = "méretToolStripMenuItem";
            méretToolStripMenuItem.Size = new Size(62, 24);
            méretToolStripMenuItem.Text = "Méret";
            // 
            // kicsiToolStripMenuItem
            // 
            kicsiToolStripMenuItem.Name = "kicsiToolStripMenuItem";
            kicsiToolStripMenuItem.Size = new Size(148, 26);
            kicsiToolStripMenuItem.Text = "Kicsi";
            kicsiToolStripMenuItem.Click += KicsiToolStripMenuItem_Click;
            // 
            // közepesToolStripMenuItem
            // 
            közepesToolStripMenuItem.Name = "közepesToolStripMenuItem";
            közepesToolStripMenuItem.Size = new Size(148, 26);
            közepesToolStripMenuItem.Text = "Közepes";
            közepesToolStripMenuItem.Click += KözepesToolStripMenuItem_Click;
            // 
            // nagyToolStripMenuItem
            // 
            nagyToolStripMenuItem.Name = "nagyToolStripMenuItem";
            nagyToolStripMenuItem.Size = new Size(148, 26);
            nagyToolStripMenuItem.Text = "Nagy";
            nagyToolStripMenuItem.Click += NagyToolStripMenuItem_Click;
            // 
            // játékMegállításaToolStripMenuItem
            // 
            játékMegállításaToolStripMenuItem.Name = "játékMegállításaToolStripMenuItem";
            játékMegállításaToolStripMenuItem.Size = new Size(137, 24);
            játékMegállításaToolStripMenuItem.Text = "Játék megállítása";
            játékMegállításaToolStripMenuItem.Click += JátékMegállításaToolStripMenuItem_Click;
            // 
            // játékFolytatásaToolStripMenuItem
            // 
            játékFolytatásaToolStripMenuItem.Name = "játékFolytatásaToolStripMenuItem";
            játékFolytatásaToolStripMenuItem.Size = new Size(125, 24);
            játékFolytatásaToolStripMenuItem.Text = "Játék folytatása";
            játékFolytatásaToolStripMenuItem.Click += játékFolytatásaToolStripMenuItem_Click;
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(20, 20);
            statusStrip1.Items.AddRange(new ToolStripItem[] { statusLabel });
            statusStrip1.Location = new Point(0, 627);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(682, 26);
            statusStrip1.TabIndex = 1;
            statusStrip1.Text = "statusStrip1";
            // 
            // statusLabel
            // 
            statusLabel.Name = "statusLabel";
            statusLabel.Size = new Size(227, 20);
            statusLabel.Text = "Enemies killed: 0 Time elapsed: 0";
            // 
            // openFileDialog
            // 
            openFileDialog.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(682, 653);
            Controls.Add(statusStrip1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "0";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fieldsToolStripMenuItem;
        private ToolStripMenuItem newGameMenuItem;
        private ToolStripMenuItem _menuFileSaveGame;
        private ToolStripMenuItem _menuFileLoad;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel statusLabel;
        private ToolStripMenuItem kilépésToolStripMenuItem;
        private ToolStripMenuItem méretToolStripMenuItem;
        private ToolStripMenuItem kicsiToolStripMenuItem;
        private ToolStripMenuItem közepesToolStripMenuItem;
        private ToolStripMenuItem nagyToolStripMenuItem;
        private OpenFileDialog openFileDialog;
        private SaveFileDialog saveFileDialog1;
        private ToolStripMenuItem játékMegállításaToolStripMenuItem;
        private ToolStripMenuItem játékFolytatásaToolStripMenuItem;
    }
}
